from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import os
import re
from datetime import datetime

app = Flask(__name__)
# 必須設定 secret_key 才能使用 session
app.secret_key = 'midtest_secret_key_1142' 

DB_FILE = 'users.json'

# --- 1. 資料存取邏輯 (符合 image_c20ac4.png 規範) ---

def load_users():
    """載入使用者資料，若檔案不存在則建立預設 admin"""
    if not os.path.exists(DB_FILE):
        default_data = {
            "users": [
                {
                    "username": "admin",
                    "email": "admin@example.com",
                    "password": "admin123",
                    "phone": "0912345678",
                    "birthdate": "1990-01-01",
                    "role": "admin"
                }
            ]
        }
        with open(DB_FILE, 'w', encoding='utf-8') as f:
            json.dump(default_data, f, indent=4, ensure_ascii=False)
        return default_data["users"]
    
    with open(DB_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)["users"]

def save_users(users_list):
    """將使用者清單存回 JSON"""
    with open(DB_FILE, 'w', encoding='utf-8') as f:
        json.dump({"users": users_list}, f, indent=4, ensure_ascii=False)


@app.template_filter('mask_phone')
def mask_phone(phone):
    """電話遮罩：0912****78"""
    if phone and len(phone) == 10:
        return f"{phone[:4]}****{phone[8:]}"
    return phone

@app.template_filter('format_tw_date')
def format_tw_date(date_str):
    """西元年轉民國年：民國79年01月01日"""
    if not date_str: return ""
    try:
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        tw_year = date_obj.year - 1911
        return f"民國{tw_year}年{date_obj.strftime('%m月%d日')}"
    except:
        return date_str


@app.route('/')
def index():
    # 檢查是否有登入資訊，傳遞給首頁顯示不同按鈕
    username = session.get('username')
    return render_template('index.html', username=username)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """註冊功能 (符合 image_c2871a.png 規範)"""
    if request.method == 'POST':
        users = load_users()
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        phone = request.form.get('phone')
        birthdate = request.form.get('birthday') # 注意 HTML name 屬性

        # 基礎驗證
        if any(u['username'] == username or u['email'] == email for u in users):
            return redirect(url_for('error_page', message='帳號或 Email 已重複'))
        
        if not (6 <= len(password) <= 16):
            return redirect(url_for('error_page', message='密碼長度需為 6-16 字元'))

        # 新增使用者
        new_user = {
            "username": username,
            "email": email,
            "password": password,
            "phone": phone,
            "birthdate": birthdate,
            "role": "user"
        }
        users.append(new_user)
        save_users(users)
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """登入功能 (符合 image_c28283.png 規範)"""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        users = load_users()
        
        user = next((u for u in users if u['email'] == email and u['password'] == password), None)
        
        if user:
            # 登入成功，記錄 Session
            session['username'] = user['username']
            session['is_admin'] = (user['username'] == 'admin')
            return redirect(url_for('announcement'))
        else:
            return redirect(url_for('error_page', message='Email 或密碼錯誤'))
            
    return render_template('login.html')

@app.route('/announcement')
def announcement():
    """系統公告 (權限檢查)"""
    if 'username' not in session:
        return redirect(url_for('error_page', message='請先登入'))
    return render_template('announcement.html', username=session['username'], is_admin=session.get('is_admin'))

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    """個人資料管理"""
    if 'username' not in session:
        return redirect(url_for('error_page', message='請先登入'))
    
    users = load_users()
    idx = next((i for i, u in enumerate(users) if u['username'] == session['username']), None)
    
    if request.method == 'POST':
        # 更新邏輯... (略)
        users[idx]['phone'] = request.form.get('phone')
        users[idx]['birthdate'] = request.form.get('birthday')
        if request.form.get('password'):
            users[idx]['password'] = request.form.get('password')
        save_users(users)
        flash("資料已更新")
        return redirect(url_for('profile'))

    return render_template('profile.html', user=users[idx])

@app.route('/users')
def user_management():
    # 1. 檢查是否有 admin 權限 (改用 username 判斷最保險)
    if not session.get('is_admin'):
        return redirect(url_for('error_page', message='無權限訪問'))
    
    # 2. 讀取資料
    users = load_users()
    
    # 3. 渲染頁面
    return render_template('users.html', users=users)

@app.route('/users/<username>/delete', methods=['POST'])
def delete_user(username):
    """刪除會員 (僅限 POST，不可刪除自己或 admin)"""
    if not session.get('is_admin'): return "Forbidden", 403
    
    users = load_users()
    # 過濾掉要刪除的人
    new_users = [u for u in users if not (u['username'] == username and u['role'] != 'admin' and u['username'] != session['username'])]
    
    if len(new_users) == len(users):
        flash("不可刪除管理員或目前登入帳號")
    else:
        save_users(new_users)
        flash(f"使用者 {username} 已刪除")
    return redirect(url_for('user_management'))

@app.route('/error')
def error_page():
    """通用錯誤頁面"""
    message = request.args.get('message', '發生未知錯誤')
    return render_template('error.html', message=message)

@app.route('/logout')
def logout():
    """登出並清除 Session"""
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)